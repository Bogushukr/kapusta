export const cashOutSixMonth = state => state.report.date.cashOutSixMonth;
export const cashInSixMonth = state => state.report.date.cashInSixMonth

