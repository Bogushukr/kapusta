import React from 'react';

import './ModalBalance.scss';

const ModalBalance = () => {
  return (
    <div className="modal">
      <span className="balanceModal"></span>
    </div>
  );
};

export default ModalBalance;
