export { default } from "./GeneratorScheduleReport";
