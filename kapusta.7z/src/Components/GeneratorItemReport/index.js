export { default } from "./GeneratorItemReport";
